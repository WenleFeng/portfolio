import React,{Component} from 'react';
import {Grid, Cell, ListItem, ListItemContent, List} from 'react-mdl';
import {Element} from 'react-scroll';


class Contact extends Component {
    render() {
        return (
            <div className= "Ccontact-body">
            <Element style={{position:'relative', top:-25,right:28, overflow: 'scroll', height:'91%',width:"99%", margin:'auto'}}>

            <Grid className="Ccontact-grid">
            <Cell col={5}>
            <h2>Wenle Feng</h2>
            <h3>(Kevin)</h3>
            <img src="https://cdn2.iconfinder.com/data/icons/avatar-2/512/Fred_man-512.png"
            alt = "avatar"
            style={{height:'250px'}}></img>
            <p style={{width:'75%', margin:'auto', paddingTop: '1em'}}>
            
            </p>
            </Cell>
            <Cell col={7}>
            <h2>Contact Me</h2>
            <hr/>
            <div className="Ccontact-list">
                <List>

                <ListItem>
                <ListItemContent style={{fontSize: '20px',fontFamily:'Anton'}}>
                <i className="fa fa-phone" aria-hidden="true"/>
                <h4   style={{fontSize: '1.7vw'}}>&nbsp;(408) 921-6506</h4>
                </ListItemContent>
                </ListItem>

                <ListItem>
                <ListItemContent style={{fontSize: '20px',fontFamily:'Anton'}}>
                <i className="fa fa-envelope" aria-hidden="true"/>
                <h4 style={{fontSize: '1.8vw'}}>wenlefeng@outlook.com</h4>
                </ListItemContent>
                </ListItem>

                <ListItem>
                <ListItemContent style={{fontSize: '18px',fontFamily:'Anton'}}>
                <i className="fa fa-home" aria-hidden="true"/>
                <h4 style={{fontSize: '1.4vw'}}>&nbsp;11565 Destination Dr, Apt 4314 Broomfield, CO 80021</h4>
                </ListItemContent>
                </ListItem>

                </List>
            </div>
            
            
            
            </Cell>
            </Grid>
            </Element>
            </div>
        )
    }
}

export default Contact;