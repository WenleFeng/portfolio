import React,{Component} from 'react';
import {Grid, Cell} from 'react-mdl';

class Landing extends Component {
    render() {
        return (
            <div style = {{width: '100%', margin: 'auto'}}>
            <Grid className="landing-graid">
                <Cell col={12}>
                    <img
                    src = "https://cdn1.iconfinder.com/data/icons/user-pictures/101/malecostume-512.png"
                    alt = "avatar"
                    className = "avatar-img">
                    </img>

                    <div className = "banner-text">
                    <h1>Full Stack Developer</h1>
                    <hr/>
                    <div className = "social-links"></div>
                    <p>Java | Python | C++ | C# | Scala | JavaScript | HTML/CSS | React | Swift </p>
                    <div className="social-links">
                    {/* LinkedIn */}
                    <a href="https://www.linkedin.com/in/wenle-feng-5164a316b/" rel="noopener noreferrer" target = "_blank">
                    <i className="fa fa-linkedin-square" aria-hidden="true" />
                    </a>

                    {/* GitHub */}
                    <a href="https://github.com/WenleFeng" rel="noopener noreferrer" target = "_blank">
                    <i className="fa fa-github" aria-hidden="true" />
                    </a>

                    {/* Instagram */}
                    <a href="https://www.instagram.com/wenle_feng/" rel="noopener noreferrer" target = "_blank">
                    <i className="fa fa-instagram" aria-hidden="true" />
                    </a>
                    
                    </div>
                    </div>
                </Cell>
            </Grid>
            </div>
        )
    }
}

export default Landing;