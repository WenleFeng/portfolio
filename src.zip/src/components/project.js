import React,{Component} from 'react';
import {Tabs, Tab, Grid, Cell, Card, CardTitle, CardActions, Button, CardMenu, CardText} from 'react-mdl';

class Project extends Component {
    constructor(props){
        super(props);
        this.state = {activeTab: 0};
    }
    toggleCategories() {
        if(this.state.activeTab === 0){
            return(
            <div className = "projects-grid">
            <Card shadow={5} style={{width: '450px', margin: 'auto'}}>
                <CardTitle style={{color: '#fff', height: '176px', background: 'url(https://londonfeministfilmfestival.files.wordpress.com/2017/05/imdb-logo.png) center / cover'}}>
                IMDB movie recommender system
                </CardTitle>
                <CardText>
                    Scrapy, HDFS, Spark, Cassandra, Java
                </CardText>

                <CardActions border>
                <a href="https://github.com/WenleFeng/IMDB-scraping-Data-processing" rel="noopener noreferrer" target = "_blank">
                    <Button colored>GitHub</Button></a>

                </CardActions>
                <CardMenu style={{color: '#fff'}}>
                </CardMenu>
        </Card>


        
        <Card shadow={5} style={{width: '450px', margin: 'auto'}}>
        <CardTitle style={{color: 'white', height: '176px', background: 'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARwAAACxCAMAAAAh3/JWAAAAkFBMVEUAl5z///8AlZsBl5sAkJYAkpcAlJsAk5cAkJeLx8qCxMf+/v/l8vLJ4+QAkJQ9pamfztDv9/d9wcS53N6m09Ww2NoAi5LU6upJq65kub2629/d7e0noKWCxcditLfj8vByvL+Tysz0+fvD4+KFwskbnaBTs7drusBNqbCHxMN1vsOPysq329+h1tdOsLNBqKp9i3JUAAAGd0lEQVR4nO2d63KiShSF+85FBUHxMhBEEzUxc+L7v93Z3Q1GE8/8OFWTVHXWFwvBxil61b703lAOYwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOCvI4QwmjZC3h+mE3REY/eHgyaK5fn4lJRto+M705da7VddeTo0Romvv7rvRGjdTXbcU1Qrmv+VApKJrJmOh+Hfb5mRTObn5vsu+AsROuE3bNrs3Xoky/LJ+9iI8/qQMfG2/Ud/4zV/FTof+0lfMdmbYViIin/ktxBN82b+9K8GgdTttVkMGu0OyhuPbsaftOF8zIz8AbHnSpuCeHeeznmNfr4M74rx+3Dx3df9FYh8sIVtLjMlmqflIEYXMWku2lQt01nE2ll/vFTh53TVO02ilMtQIlKruneuZy2a3lAqpoW0OUzE+169V/Xd1/630aWfKWVvbwiCrEVtvTo7JsbOw3bPitaG9gTamnjuvxN80NEbJ0N7k5Wlar06Ey9D0RhhddH0ZpfIyrvWNPBULnw0nsU3RYFk6iqDcd4YZzRtkrTCuZ52gbkIXBzlTSP/5CDq4X3h00aXcyc+zrhF44ivgvYrEdV29rWfsuhx+9njJU1lflBNOX9Uxg3vfRAP23SEK6jmJI40ec95L+yh7GutnYu74jktqYaoy7S1h5nLcVXQ4gjpLYDqAJNdFsKlKwt06o+2ToEhQ/WeZe1qxGdBiyOZV4OCiszqW3H6Md44P1Lv4lgvi5zTPQYtTm851jikmow9RefkiPtys4rtkd5u6mLEd3Vd2XaPdmX6LOhloImLYZK0iumJfER+G0zFpzKjFjYgL5S2Ecl/bx625WhXChSfLUCyoffF68xnbJetfJdQnN1IF3QqZ/HWzfLwaZb6Un6OXDKzHyWbTeXNKvMuF3or0Nfkdcxu5BH6qvVH2cytdMiZYr8cJMOxK8Rl9vXX+6Vk3kLmN011I/vMtT1525nG19qJvW/rdKF3AsXKlwnzzN+SsQWm6na+azrRcd+9mexjNyxt3ZV7bcbxd1/8X0f1GbtudayFjjLRDuGmjoS4xJ55o+JIm0g1w4pnFbrhMCnNsPgbV2nXbWdDJ5SPnRldhnk9T08v8yXve/GvKvh+jvWUew108iRfgbLb2HxhHvQCcEAKcW/62741KIXa3hmmBBZ+C5m51lY5+jD3SaPFxWnUeflheLwKem18i5HJlW/tZvntnQWh2sG4rIp1p/7jYYMQkVJEOk+qZV0vZ9s3pszt3Mnzsn1Z1eOiqGdJroxvtv8ghFaUyJUrLO9hlDZUlv7nePj8aeK0ACQT+2nSGLs4pnnTu3tEybqRe5TJ0NYO2n3pznMpyraZhfkZjiWas+32yXOenw05je0jM6q19uezG5OusZw3pskbKZp8L2RE23uPOIWHGvMRGYWrz0dbrfs+VpzwsYonfL7wa+TJghI601s+U+6RleonqONUaaV9m5AMbVbwJb1P45TXmXrkUzWdjflmtl1QOq8WW16pDd9U9sZM+OroKV/ymbbiLMg45ouCtyRBsRjE0Xoxo491bNc6DYnTkAUt6FvhV+VMj/mBj5xbLdiO6gISxzDOxUUcpn/ZdjGJs+SPKa9azpUu7zVXQ8OKktW81b4nuGEUc1otyDjexVGDOF3BZ1ac0Q8Rh7zKQlGWYg7nuQ3I7WJNZkTiLBZWHJH9ss0wNeFlZyPxmcwqS2xvNXQoui6rX3xHFjSikLuMo4JXc6sWGcix3fFSdemST9K1FUfV9t55wR9PBRlT6AFZrshaVDbiHYXZbM9dzCGWww2IWsSbSyp/0gf7vIp7PqUO/1l28fyS2kdvXlr28iJM+1LqMk3LFS1iRPRWli0thrunNH15anWbnIV+em2F3nfpIfruS/8KYiOpQNBCGqoIXMmgfR1BJYUxtCNNpKnmpNOMe9bdNU+jn1ZjAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwsH+KuPHT5j9AVS/K/yxP+X9s5+BeUuveLB/D2m/Tfv9fmc4Z9hl7j/pZQFr1WyTskzL7vSQvj6USXJcd+k66dYdvcr1ml5PpaVbp+t1mnRdeeqOdEinMtnsG0uoP/kkVklyIgFOJMnRvkil7kTbdH04lqdjejikx5YUOR5L2k27tdslfUic0H8Iy4rzf/kXjGdZ1CmaWzAAAAAASUVORK5CYII=) center / cover'}}>
        Soil quality real-time monitor
        </CardTitle>
        <CardText>
            C#, MySQL, arduino
        </CardText>

        <CardActions border>
        <a href="https://github.com/WenleFeng/CSCI3308_TeamRaspberries" rel="noopener noreferrer" target = "_blank">

            <Button colored>GitHub</Button>
            </a>
        </CardActions>

        <CardMenu style={{color: '#fff'}}>
        </CardMenu>
</Card>


        
        </div>
            )
        }else if(this.state.activeTab === 1){
            return(
                <div className = "projects-grid">

                <Card shadow={5} style={{width: '450px', margin: 'auto'}}>
                <CardTitle style={{color: 'black', height: '176px', background: 'url(https://cdn.dribbble.com/users/494360/screenshots/4037411/ape_logo.png) center / cover'}}>
                Chatting web app “ApeChat”
                </CardTitle>
                <CardText>
                   AWS S3, NodeJS, DynamoDB, Cognito, IAM, HTML/CSS, JavaScript
                </CardText>

                <CardActions border>
                <a href="https://github.com/WenleFeng/Serverless-chat-web-app-ApeChat-" rel="noopener noreferrer" target = "_blank">

                    <Button colored>GitHub</Button>
                    </a>
                </CardActions>

                <CardMenu style={{color: '#fff'}}>
                </CardMenu>
        </Card>
        <Card shadow={5} style={{width: '450px', margin: 'auto'}}>
                <CardTitle style={{color: '#fff', height: '176px', background: 'url(https://cdn.technadu.com/wp-content/uploads/2017/12/Create-a-library-in-kodi-Featured-696x398.jpg) center / cover'}}>
                Web front-end app “Movie Kevin”
                </CardTitle>
                <CardText>
                    ReactJS, jQuery, JavaScript
                </CardText>

                <CardActions border>
                <a href="https://github.com/WenleFeng/Movie-Kevin" rel="noopener noreferrer" target = "_blank">

                    <Button colored>GitHub</Button>
                    </a>
                </CardActions>

                <CardMenu style={{color: '#fff'}}>
                </CardMenu>
        </Card>

        </div>

            )
        }else if(this.state.activeTab === 2){
            return(
                <div className = "projects-grid">
                <Card shadow={5} style={{width: '450px', margin: 'auto'}}>
                <CardTitle style={{color: 'black', height: '176px', background: 'url(https://is2-ssl.mzstatic.com/image/thumb/Purple118/v4/06/4e/1e/064e1e9a-c087-222f-b98c-0a3ff93ca5fb/AppIcon-1x_U007emarketing-0-85-220-0-5.png/600x600wa.png) center / cover'}}>
                Lazy Sun
                </CardTitle>
                <CardText>
                    Unity 3D, PhotoShop, C#
                </CardText>

                <CardActions border>
                <a href="https://itunes.apple.com/us/app/lazy-sun/id1412568925?mt=8" rel="noopener noreferrer" target = "_blank">

                    <Button colored>App Store</Button>
                    </a>
                </CardActions>

                <CardMenu style={{color: '#fff'}}>
                </CardMenu>
                </Card>


                <Card shadow={5} style={{width: '450px', margin: 'auto'}}>
                <CardTitle style={{color: '#fff', height: '176px', background: 'url(https://is2-ssl.mzstatic.com/image/thumb/Purple128/v4/c8/37/e2/c837e248-30fb-9507-5318-72f4ea5778c6/source/392x696bb.jpg) center / cover'}}>
                Snake-1997
                </CardTitle>
                <CardText>
                Unity 3D, PhotoShop, C#
                </CardText>

                <CardActions border>
                <a href="https://itunes.apple.com/us/app/snake-1997/id1433847901" rel="noopener noreferrer" target = "_blank">

                    <Button colored>App Store</Button>
                    </a>.
                </CardActions>

                <CardMenu style={{color: '#fff'}}>
                </CardMenu>
                </Card>

                </div>

            )
        }
    }
    render() {
        return (
            <div className = "category-tabs">
            <Tabs activeTab={this.state.activeTab} onChange={(tabId) => this.setState({ activeTab: tabId })} ripple>
                    <Tab>Database</Tab>
                    <Tab>Web</Tab>
                    <Tab>IOS App</Tab>
            </Tabs>
            
            <Grid>
            <Cell col={12}>
            <div className= "content">{this.toggleCategories()}</div>
            </Cell>
            </Grid>
            </div>
        )
    }
}

export default Project;